# kendinize-ozel-site

*Alın Linkleri Falan Ayarlayın Keyfinize bakın.*

# Değişicek Şeyler

- *Linkler Değişmeli*
- *İsim Değişmeli*
- *Profil Fotoğrafı Değişmeli*
